


// var transporter = nodemailer.createTransport(smtpConfig);

module.exports.add_employee = add_employee;
module.exports.employee_detail = employee_detail;
module.exports.emp_delete = emp_delete;

function add_employee(userdata, pool, callback) {
    var resultJson = '';
    var queryinsert = '';
    var name = '';
    var id = '';
    var email = '';
    var phone = '';

    if (typeof userdata.email !== 'undefined' && userdata.email !== '') {
        email = userdata.email;
    }
    if (typeof userdata.id !== 'undefined' && userdata.id !== '' && userdata.id !== null) {
        id = userdata.id;
    }
    if (typeof userdata.name !== 'undefined' && userdata.name !== '') {
        name = userdata.name;
    }
    if (typeof userdata.phone !== 'undefined' && userdata.phone !== '') {
        phone = userdata.phone;
    }

    pool.getConnection(function (err, connection) {
        if (id === '') {
            queryinsert = 'INSERT INTO employee SET email="' + email + '", name="' + name + '", phone="' + phone + '"';
        } else {
            queryinsert = 'UPDATE employee SET email="' + email + '", name="' + name + '", phone="' + phone + '" WHERE id="' + id + '"';
        }

        connection.query(queryinsert, function (errinsert, resultinsert) {
            if (!errinsert) {
                resultJson = '{"replyCode":"success","replyMsg":"Successfully added/updated"}\n';
                connection.release();
                callback(200, null, resultJson);
                return;
            } else {
                resultJson = '{"replyCode":"error","replyMsg":"' + errinsert.message + '","cmd":"add_employee"}\n';
                connection.release();
                callback(400, null, resultJson);
                return;
            }
        });
    });
}

function emp_delete(userdata, pool, callback) {
	
	var id = '';
	var keycondition = '';
	

	if (typeof userdata.id != 'undefined' && userdata.id != '') {
		id = userdata.id;
	}
	if(id!=""){
		keycondition='where id="'+id+'"'
	}
	pool.getConnection(function (err, connection) {
				
				var queryinsert = 'Delete from employee '+keycondition+' ORDER BY `id` DESC';
               
					connection.query(queryinsert, function (errinsert, resultinsert) {
						if (!errinsert) {
                resultJson = '{"replyCode":"success","replyMsg":"Successfully delete"}\n';
							connection.release();
							callback(200, null, resultJson);
							return;
						} else {
							resultJson =
								'{"replyCode":"error","replyMsg":"' + errinsert.message + '","cmd":"emp_delete"}\n';
							// console.log('res-suceess');
							connection.release();
							callback(400, null, resultJson);
							return;
						}
					});
				
			
	});
}
function employee_detail(userdata, pool, callback) {
    var id = '';
    var keyword = '';
    var keycondition = '';

    if (typeof userdata.id != 'undefined' && userdata.id != '') {
        id = userdata.id;
    }
    if (typeof userdata.keyword != 'undefined' && userdata.keyword != '') {
        keyword = userdata.keyword;
    }
    if (id !== '') {
        keycondition = 'WHERE id="' + id + '"';
    }
    if (keyword !== '') {
        if (keycondition === '') {
            keycondition = 'WHERE ';
        } else {
            keycondition += ' AND ';
        }
        keycondition += '(name LIKE "%' + keyword + '%" OR phone LIKE "%' + keyword + '%" OR email LIKE "%' + keyword + '%")';
    }

    pool.getConnection(function (err, connection) {
        var queryinsert = 'SELECT * FROM employee ' + keycondition + ' ORDER BY id DESC';

        connection.query(queryinsert, function (errinsert, resultinsert) {
            if (!errinsert) {
                var resultJson = '{"replyCode":"success","replyMsg":"","data":' + JSON.stringify(resultinsert) + '}\n';
                connection.release();
                callback(200, null, resultJson);
                return;
            } else {
                var resultJson = '{"replyCode":"error","replyMsg":"' + errinsert.message + '","cmd":"employee_detail"}\n';
                connection.release();
                callback(400, null, resultJson);
                return;
            }
        });
    });
}

